package com.pdfGeneration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfGeneration1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
